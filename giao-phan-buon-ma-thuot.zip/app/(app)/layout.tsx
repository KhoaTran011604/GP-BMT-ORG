'use client';

import React from "react"

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Menu, X, LogOut } from 'lucide-react';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: '📊' },
  { name: 'Giáo xứ', href: '/parish', icon: '⛪' },
  { name: 'Giáo dân', href: '/people', icon: '👥' },
  { name: 'Tài chính', href: '/finance', icon: '💰' },
  { name: 'Linh mục', href: '/clergy', icon: '👨‍🎓' },
  { name: 'Nhân sự', href: '/hr', icon: '👔' },
  { name: 'Hành chính', href: '/admin', icon: '📋' },
  { name: 'Báo cáo', href: '/reports', icon: '📈' },
  { name: 'Cài đặt', href: '/settings', icon: '⚙️' },
];

export default function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Đang tải...</h2>
          <p className="text-gray-600">Vui lòng chờ</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-20'
        } bg-blue-900 text-white transition-all duration-300 flex flex-col`}
      >
        {/* Logo */}
        <div className="p-4 border-b border-blue-800 flex items-center justify-between">
          {sidebarOpen && (
            <div>
              <h1 className="text-xl font-bold">GPBMT</h1>
              <p className="text-xs text-blue-300">Quản lý Giáo phận</p>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1 hover:bg-blue-800 rounded"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-2">
          {navigation.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-4 py-2 rounded hover:bg-blue-800 transition-colors"
              title={sidebarOpen ? '' : item.name}
            >
              <span className="text-xl">{item.icon}</span>
              {sidebarOpen && <span className="text-sm">{item.name}</span>}
            </Link>
          ))}
        </nav>

        {/* User Info & Logout */}
        <div className="p-4 border-t border-blue-800">
          {sidebarOpen && (
            <div className="mb-4 pb-4 border-b border-blue-800">
              <p className="text-sm font-medium truncate">{user?.fullName}</p>
              <p className="text-xs text-blue-300 truncate">{user?.email}</p>
              <p className="text-xs text-blue-400 mt-1">
                {user?.role === 'super_admin' && 'Super Admin'}
                {user?.role === 'cha_quan_ly' && 'Cha Quản lý'}
                {user?.role === 'cha_xu' && 'Cha xứ'}
                {user?.role === 'ke_toan' && 'Kế toán VP'}
                {user?.role === 'thu_ky' && 'Thư ký GX'}
              </p>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-4 py-2 rounded hover:bg-blue-800 transition-colors text-sm"
          >
            <LogOut size={18} />
            {sidebarOpen && 'Đăng xuất'}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Hệ thống Quản lý Giáo phận</h2>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">{new Date().toLocaleDateString('vi-VN')}</span>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
